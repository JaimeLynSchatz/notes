module Editors 
  ALL_EDITORS = [ "potlatch", "potlatch2", "id", "remote" ]
  RECOMMENDED_EDITORS = [ "id", "potlatch2", "remote" ]
end
