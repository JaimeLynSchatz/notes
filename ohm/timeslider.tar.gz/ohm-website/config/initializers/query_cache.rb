Rails.configuration.middleware.delete ActiveRecord::QueryCache
