require 'output_compression/output_compression'
