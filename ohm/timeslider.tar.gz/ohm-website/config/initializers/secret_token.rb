# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
OpenStreetMap::Application.config.secret_key_base = '8be565e2e25831d88231f4bcfd83dfc3ab33957c4f33bb3cff7a279f7820ec4d0c1111f246bb347c68859c0b46b4e591be9179a53a5a7165a9936000d6d2be41'
