module NotifierHelper
  def fp(text)
    format_paragraph(text, 72, 0)
  end
end
